import discord
import os

client = discord.Client()

trigger_words=["china", "c.h.i.n.a", "ice cream", "asscream", "bing chilling", "bing"]
ts=["tianemen square", "Tiananmen Square", "tiananmen square", "Tianemen square", "taiwan", "genocide"]

@client.event
async def on_ready():
  print('we have logged in as {0.user}'.format(client))  

@client.event
async def on_message(message):
  if message.author==client.user:
    return

  msg=message.content

  if any(word in msg for word in trigger_words):
    await message.channel.send("https://cdn.discordapp.com/attachments/709277016901419050/873142321565290516/bing_chilling.mp4")
  
  if any(word in msg for word in ts):
    message.delete()


client.run(os.getenv('TOKEN'))